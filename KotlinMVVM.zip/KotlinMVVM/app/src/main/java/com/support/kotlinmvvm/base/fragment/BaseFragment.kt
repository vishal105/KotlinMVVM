package com.support.kotlinmvvm.base.fragment

import android.arch.lifecycle.ViewModelProviders
import android.content.Context
import android.databinding.DataBindingUtil
import android.databinding.ViewDataBinding
import android.os.Bundle
import android.support.annotation.LayoutRes
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.support.kotlinmvvm.base.activity.BaseActivity
import com.support.kotlinmvvm.base.viewmodel.BaseViewModel

abstract class BaseFragment<VM : BaseViewModel,
        DB : ViewDataBinding>(private val mViewModelClass: Class<VM>) :
    Fragment() {

    var binding: DB? = null
        private set
    var baseActivity: BaseActivity<*, *>? = null
        private set
    private var mRootView: View? = null

    private fun getViewModel(viewmodel: Class<VM>): VM {
        return ViewModelProviders.of(this).get(viewmodel)
    }

    var viewModel: VM? = null

    abstract fun initViewModel(viewModel: VM)

    abstract val bindingVariable: Int

    @get:LayoutRes
    abstract val layoutId: Int

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        if (context is BaseActivity<*, *>) {
            val activity = context as BaseActivity<*, *>?
            this.baseActivity = activity
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        viewModel = createViewModel(this)
        super.onCreate(savedInstanceState)
        retainInstance = true
        viewModel?.apply {
            lifecycle.addObserver(this)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        binding = DataBindingUtil.inflate(inflater, layoutId, container, false)
        mRootView = binding?.root
        return mRootView
    }

    override fun onDetach() {
        baseActivity = null
        super.onDetach()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding?.setVariable(bindingVariable, viewModel)
        binding?.executePendingBindings()

        initData()
    }

    abstract fun initData()

    override fun onDestroy() {
        super.onDestroy()
        viewModel?.apply {
            lifecycle.removeObserver(this)
        }
        binding?.unbind()
    }

    open fun createViewModel(activity: FragmentActivity): VM {
        return ViewModelProviders.of(activity).get(mViewModelClass)
    }

    open fun createViewModel(fragment: Fragment): VM {
        return ViewModelProviders.of(fragment).get(mViewModelClass)
    }

}